@extends('frontend.master-frontend')
@section('content')
<br>

<div class='container-fluid'>
    <div class='page_banner_img_common'>
        <img src='/frontend/images/pages-banner.png' class='img-fluid'>
        <div class='overlay__'>
            <p>Course Material</p>
        </div>
    </div>
    
    
</div>

@endsection
