@extends('frontend.master-frontend')
@section('content')

<div class='container-fluid'>
    <div class='page_banner_img_common'>
        <img src='/frontend/images/pages-banner.png' class='img-fluid'>
        <div class='overlay__'>
            <p>Question Bank</p>
        </div>
    </div>
        
</div>

@endsection
